N = input("Quellez est la moyenne de l'eleve : ")

if N >= 16:
    print("Mention TB")
elif N >= 14:
    print("Mention B")
elif N >= 12:
    print("Mention AB")
elif N >= 10:
    print("Admis")
else:
    print("Ajourne")