void ANVACER(int action);
void RECULER(int action);
void TOURNER_D(int action);
void TOURNER_G(int action);
