#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"fonction.h"

void ANVACER(int action)
{
    if(action == 1)
    {
        printf("ANVACER\n");
    } 
}

void RECULER(int action)
{
    if(action == 1)
    {
        printf("RECULER\n");
    } 
}

void TOURNER_D(int action)
{
    if(action == 1)
    {
        printf("TOURNER_D\n");
    } 
}

void TOURNER_G(int action)
{
    if(action == 1)
    {
        printf("TOURNER_G\n");
    } 
}